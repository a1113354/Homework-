import java.util.*;
public class main {
    public static void showInfo() {
        System.out.println("歡迎进入冰雪奇缘系统");
    }
    public static void main(String[] args) {
        showInfo();

        Animal xuebao = new Animal("雪寶", 60, 25, 40);
        Animal lvzi = new Animal("驢子", 110, 50, 30);

        Human ake = new Human("阿克", 180, 70, 50, "男");
        Human hans = new Human("漢斯", 185, 75, 55, "男");
        Human ana = new Human("安娜", 170, 60, 45, "女");

        Snow elsa = new Snow("艾莎", 170, 60, 45, "女", true);
        Snow anna = new Snow("安娜", 165, 55, 50, "女",false);

        xuebao.show();
        lvzi.show();
        ake.show();
        hans.show();
        ana.show();
        elsa.show();
        anna.show();

        Scanner scanner = new Scanner(System.in);
        System.out.print("請輸入 x 值：");
        double x = scanner.nextDouble();
        System.out.print("請輸入 y 值：");
        double y = scanner.nextDouble();

        System.out.println(xuebao.getName() + " 奔跑距離：" + xuebao.distance(x, y));
        System.out.println(lvzi.getName() + " 奔跑距離：" + lvzi.distance(x, y));
        System.out.println(ake.getName() + " 奔跑距離：" + ake.distance(x, y));
        System.out.println(hans.getName() + " 奔跑距離：" + hans.distance(x, y));
        System.out.println(ana.getName() + " 奔跑距離：" + ana.distance(x, y));
        System.out.println(elsa.getName() + " 奔跑距離：" + elsa.distance(x, y));
        System.out.println(anna.getName() + " 奔跑距離：" + anna.distance(x, y));
    }
}
