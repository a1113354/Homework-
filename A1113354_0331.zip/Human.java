public class Human extends Animal {
    public String gender;

    public Human(String name, double height, double weight, double speed, String gender) {
        super(name, height, weight, speed);
        this.gender = gender;
    }

    public void show() {
        super.show();
        System.out.println("Gender: " + gender);
    }
    public String getName() {
        return this.name;
    }
}
