import java.util.Scanner;
public class Dis {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter x (in minutes): ");
        double x = scanner.nextDouble();
        System.out.print("Enter y (acceleration, in m/s^2): ");
        double y = scanner.nextDouble();
        double distance = x * y * 0.00277778; // 0.00277778 km/min = 1 km/hr / 60 min/hr
        System.out.println("The distance traveled is " + distance + " km.");
    }
}