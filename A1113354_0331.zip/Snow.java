public class Snow extends Human {
    private boolean hasIceSkill;

    public Snow(String name, int height, int weight, int speed, String gender, boolean hasIceSkill) {
        super(name, height, weight, speed, gender);
        this.hasIceSkill = hasIceSkill;
    }

    public void show() {
        super.show();
        System.out.println("Has Ice Skill: " + hasIceSkill);
    }

    public double distance(double x) {
        if (hasIceSkill) {
            return x * speed * 2;
        } else {
            return super.distance(x);
        }
    }

    public double distance(double x, double y) {
        if (hasIceSkill) {
            return x * y * speed * 2;
        } else {
            return super.distance(x, y);
        }
    }
}
