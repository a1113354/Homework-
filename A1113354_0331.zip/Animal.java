public class Animal {
    public String name;
    private double height;
    private double weight;
    public double speed;
    
    public Animal(String name, double height, double weight, double speed) {
        this.name = name;
        this.height = height;
        this.weight = weight;
        this.speed = speed;
    }
    
    public void show() {
        System.out.println("Name: " + name);
        System.out.println("Height: " + height + " cm");
        System.out.println("Weight: " + weight + " kg");
        System.out.println("Speed: " + speed + " km/h");
    }
    
    public double distance(double x) {
        return x * speed;
    }
    
    public double distance(double x, double y) {
        return x * y * speed;
    }
    public String getName() {
        return this.name;
    }
}